{{-- <x-frontend.contact> --}}
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
    Launch demo modal
  </button>
  
  <!-- Modal -->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2659.0853710838887!2d89.43610851402396!3d25.900257909175004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39e2d9005c81ece1%3A0x398763dcf66b5eac!2z4Kah4Ka-4Kef4Ka-4Kas4KeH4Kaf4Ka_4KaVIOCmuOCmruCmv-CmpOCmvywg4Kay4Ka-4Kay4Kau4Kao4Ka_4Kaw4Ka54Ka-4Kaf!5e1!3m2!1sbn!2sbd!4v1652092079419!5m2!1sbn!2sbd" width="200"  height="200" style="border:20px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">SBFNI</iframe>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          {{-- <button type="button" class="btn btn-primary">Save changes</button> --}}
        </div>
      </div>
    </div>
  </div>
{{-- </x-frontend.contact> --}}