<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; SBFNI, {{ now()->year }}</div>
            <div>
                <a href="https://www.breakitsolution.com" target="blank">Develop by Break-IT</a>
                <a href="" target="blank">HelpLine</a>
            </div>
        </div>
    </div>
</footer>