<x-frontend.layouts.master>
    <section class="section breadcrumb-modern context-dark parallax-container text-center" data-parallax-img="{{ asset('ui/frontend/images/slider/bannar.png') }}">
        <div class="parallax-content section-30 section-sm-70">
            <div class="shell">
                <h2 class="veil reveal-sm-block" style="color:yellow;">Payment Guidelines</h2>
                <div class="offset-sm-top-35">
                    <ul class="list-inline list-inline-lg list-inline-dashed p">
                        <li><a href="{{ route('home') }}">Home</a></li>
                        <li style="color:yellow;">payment guidelines&nbsp;</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section style="margin:200px;">
        <h3 class="page-headings" style="padding: 10px 10px">Payment Guidelines:</h3>
        <p class="page-para">Our office is on the fifth floor. Academic building. You have to come to the office room and deposit money in the account section and if anyone pays money to our account number from any branch of Mercantile Bank, we will update the register as soon as the deposit slip is paid to us.
        </p>

    </section>


</x-frontend.layouts.master>